"""
constants.py – minimaler Stub für Garden Graph
"""
DEFAULT_COLOR = (0.5, 0.9, 1.0, 1)
DEFAULT_LINE_WIDTH = 1.5
