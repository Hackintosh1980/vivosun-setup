# -*- coding: utf-8 -*-
"""
Kivy Garden Graph – Stable Version (reconstructed)
© 2025 Dominik Rosenthal (Hackintosh1980) – based on Kivy Garden 0.3.1
"""

from math import ceil
from kivy.uix.widget import Widget
from kivy.properties import (
    ListProperty, NumericProperty, BooleanProperty,
    ObjectProperty, StringProperty
)
from kivy.event import EventDispatcher
from kivy.graphics import Color, Line, Rectangle
from kivy.graphics.instructions import InstructionGroup
from kivy.clock import Clock


# ---------------------------------------------------------------------
# MeshLinePlot
# ---------------------------------------------------------------------
class MeshLinePlot(EventDispatcher):
    """Simple line plot used by Graph."""
    color = ListProperty([1, 0, 0, 1])
    points = ListProperty([])

    def __init__(self, color=(1, 0, 0, 1), points=None, **kwargs):
        super().__init__(**kwargs)
        self.color = color
        self.points = points or []


# ---------------------------------------------------------------------
# Graph Widget
# ---------------------------------------------------------------------
class Graph(Widget):
    xlabel = StringProperty('')
    ylabel = StringProperty('')
    x_ticks_minor = NumericProperty(5)
    x_ticks_major = NumericProperty(25)
    y_ticks_minor = NumericProperty(5)
    y_ticks_major = NumericProperty(25)
    x_grid_label = BooleanProperty(True)
    y_grid_label = BooleanProperty(True)
    xmin = NumericProperty(0)
    xmax = NumericProperty(100)
    ymin = NumericProperty(0)
    ymax = NumericProperty(100)
    x_grid = BooleanProperty(True)
    y_grid = BooleanProperty(True)
    padding = NumericProperty(10)
    precision = StringProperty('%.1f')
    draw_border = BooleanProperty(True)
    background_color = ListProperty([0, 0, 0, 1])
    border_color = ListProperty([1, 1, 1, 1])
    tick_color = ListProperty([0.5, 0.5, 0.5, 1])
    label_options = ObjectProperty({'color': (1, 1, 1, 1), 'bold': False})
    font_size = NumericProperty(12)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._plots = []
        self._mesh_instructions = {}
        self._update_trigger = Clock.create_trigger(self._redraw)

        with self.canvas.before:
            self._bg_color = Color(rgba=self.background_color)
            self._bg_rect = Rectangle()

        with self.canvas.after:
            self._border_color = Color(rgba=self.border_color)
            self._border = Line(rectangle=(0, 0, 0, 0), width=1)

        self.bind(
            size=self._update_trigger, pos=self._update_trigger,
            xmin=self._update_trigger, xmax=self._update_trigger,
            ymin=self._update_trigger, ymax=self._update_trigger,
            x_ticks_major=self._update_trigger,
            y_ticks_major=self._update_trigger,
            draw_border=self._update_trigger
        )

    # -----------------------------------------------------------------
    def add_plot(self, plot):
        """Add a MeshLinePlot to the graph."""
        if plot in self._plots:
            return
        self._plots.append(plot)
        instr = InstructionGroup()
        instr.add(Color(rgba=plot.color))
        instr.add(Line(points=[]))
        self.canvas.add(instr)
        self._mesh_instructions[plot] = instr
        self._update_trigger()

    # -----------------------------------------------------------------
    def remove_plot(self, plot):
        """Remove a plot."""
        if plot not in self._plots:
            return
        self.canvas.remove(self._mesh_instructions[plot])
        del self._mesh_instructions[plot]
        self._plots.remove(plot)
        self._update_trigger()

    # -----------------------------------------------------------------
    def clear_plots(self):
        """Remove all plots."""
        for p in list(self._plots):
            self.remove_plot(p)

    # -----------------------------------------------------------------
    def get_plot_points(self, plot):
        """Return current data points of a plot."""
        return getattr(plot, 'points', [])

    # -----------------------------------------------------------------
    # Drawing logic
    # -----------------------------------------------------------------
    def _redraw(self, *_):
        if not self.get_parent_window():
            return

        # Background + border update
        self._bg_color.rgba = self.background_color
        self._border_color.rgba = self.border_color

        x, y = self.pos
        w, h = self.size
        px = self.padding
        gx, gy = x + px, y + px
        gw, gh = w - 2 * px, h - 2 * px

        if gw <= 0 or gh <= 0:
            return

        self._bg_rect.pos = (x, y)
        self._bg_rect.size = (w, h)
        if self.draw_border:
            self._border.rectangle = (x, y, w, h)
        else:
            self._border.rectangle = (0, 0, 0, 0)

        # Remove old grid lines
        self.canvas.remove_group('grid')
        with self.canvas:
            Color(*self.tick_color)
            if self.x_grid and self.x_ticks_major > 0:
                for i in range(1, self.x_ticks_major):
                    xx = gx + i * gw / self.x_ticks_major
                    Line(points=[xx, y + px, xx, y + h - px], group='grid')
            if self.y_grid and self.y_ticks_major > 0:
                for i in range(1, int(self.y_ticks_major)):
                    yy = gy + i * gh / self.y_ticks_major
                    Line(points=[x + px, yy, x + w - px, yy], group='grid')

        # Plot data lines
        for plot in self._plots:
            pts = []
            for px_, py_ in plot.points:
                if self.xmax == self.xmin or self.ymax == self.ymin:
                    continue
                tx = gx + ((px_ - self.xmin) / (self.xmax - self.xmin)) * gw
                ty = gy + ((py_ - self.ymin) / (self.ymax - self.ymin)) * gh
                pts.extend((tx, ty))
            instr = self._mesh_instructions[plot]

            # find actual Line() instruction
            line_instr = next((c for c in instr.children if isinstance(c, Line)), None)
            if line_instr:
                line_instr.points = pts


__all__ = ["Graph", "MeshLinePlot"]
