# -*- coding: utf-8 -*-
"""
Kivy Garden Graph – Stable Fixed Version 🌿
© 2025 Dominik Rosenthal (Hackintosh1980)
"""

from kivy.uix.widget import Widget
from kivy.properties import (
    ListProperty, NumericProperty, BooleanProperty,
    ObjectProperty, StringProperty
)
from kivy.graphics import Color, Line, Rectangle, InstructionGroup
from kivy.clock import Clock


# ---------------------------------------------------------------------
# MeshLinePlot
# ---------------------------------------------------------------------
class MeshLinePlot:
    """Simple line plot used by Graph."""
    def __init__(self, color=(1, 0, 0, 1), points=None):
        self.color = color
        self.points = points or []


# ---------------------------------------------------------------------
# Graph Widget
# ---------------------------------------------------------------------
class Graph(Widget):
    xlabel = StringProperty('')
    ylabel = StringProperty('')
    xmin = NumericProperty(0)
    xmax = NumericProperty(100)
    ymin = NumericProperty(0)
    ymax = NumericProperty(100)
    x_ticks_major = NumericProperty(10)
    y_ticks_major = NumericProperty(10)
    x_grid = BooleanProperty(True)
    y_grid = BooleanProperty(True)
    padding = NumericProperty(10)
    draw_border = BooleanProperty(True)
    background_color = ListProperty([0, 0, 0, 1])
    border_color = ListProperty([0.4, 0.4, 0.4, 1])
    tick_color = ListProperty([0.3, 0.3, 0.3, 1])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._plots = []
        self._plot_instructions = {}
        self._trigger = Clock.create_trigger(self._redraw)

        with self.canvas.before:
            self._bg_color = Color(rgba=self.background_color)
            self._bg_rect = Rectangle()

        with self.canvas.after:
            self._border_color = Color(rgba=self.border_color)
            self._border = Line(rectangle=(0, 0, 0, 0), width=1)

        self.bind(
            pos=self._trigger, size=self._trigger,
            xmin=self._trigger, xmax=self._trigger,
            ymin=self._trigger, ymax=self._trigger,
        )
        self._trigger()

    # -----------------------------------------------------------------
    def add_plot(self, plot):
        if plot in self._plots:
            return
        self._plots.append(plot)
        instr = InstructionGroup()
        instr.add(Color(rgba=plot.color))
        line = Line(points=[], width=1.2)
        instr.add(line)
        self._plot_instructions[plot] = line
        self.canvas.add(instr)
        self._trigger()

    # -----------------------------------------------------------------
    def _redraw(self, *_):
        if not self.get_parent_window():
            return

        # Background
        self._bg_color.rgba = self.background_color
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

        # Border
        if self.draw_border:
            self._border_color.rgba = self.border_color
            self._border.rectangle = (*self.pos, *self.size)

        # Grid
        x, y = self.pos
        w, h = self.size
        px = self.padding
        gx, gy = x + px, y + px
        gw, gh = w - 2 * px, h - 2 * px

        self.canvas.remove_group("grid")
        with self.canvas:
            Color(*self.tick_color)
            if self.x_grid:
                for i in range(1, int(self.x_ticks_major)):
                    xx = gx + i * gw / self.x_ticks_major
                    Line(points=[xx, gy, xx, gy + gh], width=0.5, group="grid")
            if self.y_grid:
                for j in range(1, int(self.y_ticks_major)):
                    yy = gy + j * gh / self.y_ticks_major
                    Line(points=[gx, yy, gx + gw, yy], width=0.5, group="grid")

        # Plots
        for plot in self._plots:
            pts = []
            for px_, py_ in plot.points:
                if self.xmax == self.xmin or self.ymax == self.ymin:
                    continue
                tx = gx + ((px_ - self.xmin) / (self.xmax - self.xmin)) * gw
                ty = gy + ((py_ - self.ymin) / (self.ymax - self.ymin)) * gh
                pts.extend((tx, ty))
            line = self._plot_instructions.get(plot)
            if line:
                line.points = pts


__all__ = ["Graph", "MeshLinePlot"]
