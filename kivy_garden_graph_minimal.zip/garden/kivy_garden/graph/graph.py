
# Minimal Graph widget compatible with Kivy 2.3+
# NOTE: This is a lightweight stand-in for kivy_garden.graph
#       with Graph + MeshLinePlot API sufficient for line plots.

from kivy.uix.widget import Widget
from kivy.graphics import Color, Line, Rectangle
from kivy.properties import ListProperty, NumericProperty, BooleanProperty
from kivy.clock import Clock

class MeshLinePlot:
    def __init__(self, points=None, color=(0.3, 1.0, 0.6, 1.0)):
        self.points = points or []
        self.color = color

class Graph(Widget):
    xmin = NumericProperty(0.0)
    xmax = NumericProperty(60.0)
    ymin = NumericProperty(0.0)
    ymax = NumericProperty(100.0)

    x_ticks_major = NumericProperty(10.0)
    y_ticks_major = NumericProperty(10.0)
    x_grid = BooleanProperty(True)
    y_grid = BooleanProperty(True)

    background_color = ListProperty([0.05, 0.07, 0.06, 1.0])
    tick_color = ListProperty([0.35, 0.80, 0.45, 1.0])
    draw_border = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._plots = []
        with self.canvas.before:
            self._bg_color = Color(*self.background_color)
            self._bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._redraw_bg, size=self._redraw_bg,
                  xmin=self._trigger_redraw, xmax=self._trigger_redraw,
                  ymin=self._trigger_redraw, ymax=self._trigger_redraw)
        self._redraw_ev = Clock.create_trigger(lambda *_: self._redraw(), 0)

    def _redraw_bg(self, *_):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size
        self._trigger_redraw()

    def _trigger_redraw(self, *_):
        self._redraw_ev()

    def add_plot(self, plot):
        if plot not in self._plots:
            self._plots.append(plot)
            self._trigger_redraw()

    def remove_plot(self, plot):
        if plot in self._plots:
            self._plots.remove(plot)
            self._trigger_redraw()

    def _norm(self, x, y):
        # map data coords → pixel coords inside widget
        if self.xmax == self.xmin: 
            nx = 0
        else:
            nx = (x - self.xmin) / float(self.xmax - self.xmin)
        if self.ymax == self.ymin:
            ny = 0
        else:
            ny = (y - self.ymin) / float(self.ymax - self.ymin)
        px = self.x + nx * self.width
        py = self.y + ny * self.height
        return px, py

    def _redraw(self, *_):
        # clear dynamic canvas and re-draw plots
        self.canvas.after.clear()
        with self.canvas.after:
            for plot in self._plots:
                if not plot.points:
                    continue
                Color(*plot.color)
                pts = []
                for i in range(0, len(plot.points), 2):
                    x = plot.points[i]
                    y = plot.points[i+1]
                    px, py = self._norm(x, y)
                    pts.extend([px, py])
                if len(pts) >= 4:
                    Line(points=pts, width=1.2)
