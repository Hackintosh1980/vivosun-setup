package org.hackintosh1980.blebridge;

import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.util.Log;
import android.util.SparseArray;
import org.json.*;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

public class BleBridgePersistent {

    private static final String TAG = "BleBridgePersistent";
    private static volatile boolean running = false;
    private static BluetoothLeScanner scanner;
    private static ScanCallback scanCallback;
    private static File outFile;
    private static final List<JSONObject> buffer = new ArrayList<>();
    private static final Object bufferLock = new Object();
    private static Thread writerThread;

    private static final int RSSI_MIN = -90;
    private static final int MIN_PAYLOAD_LEN = 14;
    private static final long WRITE_INTERVAL_MS = 500L; // schneller flush

    private static JSONObject parsePayload(String name, String mac, int rssi, byte[] payload) {
        try {
            if (payload == null || payload.length < MIN_PAYLOAD_LEN) return null;
            if (rssi < RSSI_MIN) return null;
            ByteBuffer bb = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
            if (bb.remaining() >= 6) bb.position(6);
            if (bb.remaining() >= 2) bb.getShort();

            float tInt = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16f) : 0f;
            float hInt = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16f) : 0f;
            float tExt = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16f) : 0f;
            float hExt = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16f) : 0f;
            int pkt = (bb.remaining() > 0) ? (bb.get() & 0xFF) : -1;

            JSONObject o = new JSONObject();
            o.put("name", name == null ? "" : name);
            o.put("address", mac == null ? "" : mac);
            o.put("rssi", rssi);
            o.put("temperature_int", tInt);
            o.put("humidity_int", hInt);
            o.put("temperature_ext", tExt);
            o.put("humidity_ext", hExt);
            o.put("packet_counter", pkt);
            return o;
        } catch (Exception e) {
            Log.w(TAG, "parsePayload error", e);
            return null;
        }
    }

    public static String start(Context ctx, String outFileName) {
        try {
            if (running) return "ALREADY_RUNNING";
            running = true;
            Log.i(TAG, "Initialize bridge…");

            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bm == null) { running = false; return "NO_BT_MANAGER"; }
            BluetoothAdapter adapter = bm.getAdapter();
            if (adapter == null || !adapter.isEnabled()) { running = false; return "BT_OFF"; }

            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { running = false; return "NO_SCANNER"; }

            outFile = new File(ctx.getFilesDir(), outFileName);

            // ⚙️ High-Flow Scan-Settings
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .setReportDelay(0)
                    .build();

            // nur ThermoBeacon2 zulassen
            scanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int type, ScanResult result) {
                    try {
                        if (result == null || result.getDevice() == null) return;
                        String name = result.getDevice().getName();
                        if (name == null || !name.equals("ThermoBeacon2")) return;
                        String addr = result.getDevice().getAddress();
                        int rssi = result.getRssi();

                        SparseArray<byte[]> mdata = result.getScanRecord().getManufacturerSpecificData();
                        if (mdata == null || mdata.size() == 0) return;

                        int bestLen = 0; byte[] payload = null;
                        for (int i = 0; i < mdata.size(); i++) {
                            byte[] p = mdata.valueAt(i);
                            if (p != null && p.length > bestLen) { bestLen = p.length; payload = p; }
                        }
                        if (payload == null) return;

                        JSONObject parsed = parsePayload(name, addr, rssi, payload);
                        if (parsed != null) {
                            synchronized (bufferLock) { buffer.add(parsed); }
                            Log.i(TAG, String.format(
                                    "OK %s rssi=%d Tin=%.1f Hin=%.1f Tex=%.1f Hex=%.1f pkt=%d",
                                    name, rssi,
                                    parsed.optDouble("temperature_int", 0.0),
                                    parsed.optDouble("humidity_int", 0.0),
                                    parsed.optDouble("temperature_ext", 0.0),
                                    parsed.optDouble("humidity_ext", 0.0),
                                    parsed.optInt("packet_counter", -1)
                            ));
                        }
                    } catch (Exception e) { Log.e(TAG, "onScanResult", e); }
                }
            };

            // Writer – doppelte Geschwindigkeit
            writerThread = new Thread(() -> {
                try {
                    while (running) {
                        Thread.sleep(WRITE_INTERVAL_MS);
                        List<JSONObject> snapshot;
                        synchronized (bufferLock) {
                            if (buffer.isEmpty()) continue;
                            snapshot = new ArrayList<>(buffer);
                            buffer.clear();
                        }
                        JSONArray arr = new JSONArray(snapshot);
                        File tmp = new File(outFile.getAbsolutePath() + ".tmp");
                        try (FileOutputStream fos = new FileOutputStream(tmp, false)) {
                            fos.write(arr.toString().getBytes());
                            fos.flush();
                        }
                        tmp.renameTo(outFile);
                        Log.d(TAG, "JSON flush (" + arr.length() + ")");
                    }
                } catch (Throwable t) { Log.e(TAG, "Writer", t); }
            });
            writerThread.start();

            // Scan-Thread sofort starten
            new Thread(() -> {
                try {
                    scanner.startScan(null, settings, scanCallback);
                    Log.i(TAG, "High-flow scan started (ThermoBeacon2)");
                    while (running) Thread.sleep(1000);
                } catch (Throwable t) {
                    Log.e(TAG, "Scan loop", t);
                }
            }).start();

            return "OK:RUNNING";
        } catch (Throwable t) {
            running = false;
            Log.e(TAG, "start", t);
            return "ERR:" + t.getMessage();
        }
    }

    public static String stop() {
        try {
            if (!running) return "NOT_RUNNING";
            running = false;
            if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback);
            Log.i(TAG, "Bridge stopped");
            return "OK:STOPPED";
        } catch (Throwable t) {
            Log.e(TAG, "stop", t);
            return "ERR:" + t.getMessage();
        }
    }
}
