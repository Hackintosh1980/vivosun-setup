package org.hackintosh1980.blebridge;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.util.Log;
import android.util.SparseArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class BleBridgePersistent {

    private static final String TAG = "BleBridgePersistent";
    private static final boolean DEBUG = true;

    private static volatile boolean running = false;
    private static BluetoothLeScanner scanner;
    private static ScanCallback callback;
    private static File outFile;

    // Hält je Gerätetyp den letzten gültigen Messpunkt → verhindert Vermischen
    private static final Object lock = new Object();
    private static final Map<String, JSONObject> lastSeenByType = new HashMap<>(2);

    // Protokoll- und Tuningwerte
    private static final int RSSI_MIN = -95;
    private static final int COMPANY_ID = 0x0019;                // VIVOSUN/ThermoBeacon
    private static final int NEED_MIN  = 2 + 6 + 2 + (2 * 4) + 1; // cid + 6 + 2 + 4*short + pkt

    private static final long WRITE_MS    = 100L;  // Writer-Flush
    private static final long THROTTLE_MS = 50L;   // Ereignisdrossel

    private static long lastAppend = 0L;

    // -----------------------------------------------------------
    // Start / Stop
    // -----------------------------------------------------------
    public static String start(Context ctx, String outFileName) {
        try {
            if (running) return "ALREADY_RUNNING";
            running = true;

            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = bm != null ? bm.getAdapter() : null;
            if (adapter == null || !adapter.isEnabled()) {
                running = false;
                return "BT_OFF";
            }

            BluetoothLeScanner sc = adapter.getBluetoothLeScanner();
            if (sc == null) {
                running = false;
                return "NO_SCANNER";
            }
            scanner = sc;

            outFile = new File(ctx.getFilesDir(), outFileName);
            if (DEBUG) Log.i(TAG, "Start → file=" + outFile.getAbsolutePath());

            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .setReportDelay(200) // milde Batchung, schnell genug
                    .build();

            // ✅ Catch-all Filter: einige Geräte liefern sonst keine Ergebnisse
            List<ScanFilter> filters = new ArrayList<>();
            filters.add(new ScanFilter.Builder().build());

            callback = new ScanCallback() {
                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    for (ScanResult r : results) handleOne(r);
                }

                @Override
                public void onScanResult(int callbackType, ScanResult r) {
                    handleOne(r);
                }

                private void handleOne(ScanResult r) {
                    try {
                        if (r == null || r.getDevice() == null) return;

                        String name = r.getDevice().getName();
                        if (name == null) name = "";
                        final String mac  = r.getDevice().getAddress();
                        final int rssi    = r.getRssi();
                        if (rssi < RSSI_MIN) return;

                        ScanRecord rec = r.getScanRecord();
                        if (rec == null) return;

                        SparseArray<byte[]> md = rec.getManufacturerSpecificData();
                        if (md == null || md.size() == 0) return;

                        // Bevorzugt 0x0019, sonst längster Block
                        byte[] payload = md.get(COMPANY_ID);
                        if (payload == null) {
                            int bestLen = 0;
                            for (int i = 0; i < md.size(); i++) {
                                byte[] p = md.valueAt(i);
                                if (p != null && p.length > bestLen) {
                                    bestLen = p.length;
                                    payload = p;
                                }
                            }
                        }
                        if (payload == null) return;

                        long now = System.currentTimeMillis();
                        if (now - lastAppend < THROTTLE_MS) return;
                        lastAppend = now;

                        // Stabiler Gerätetyp (Controller vs Sensor)
                        final String devType = classify(name, mac);

                        JSONObject j = decodePayload(name, mac, rssi, payload, devType);
                        if (j == null) return;

                        synchronized (lock) {
                            // Pro Typ genau EIN letzter Messpunkt → kein Überschreiben zwischen Typen
                            lastSeenByType.put(devType, j);
                        }

                        if (DEBUG) {
                            Log.i(TAG, String.format(Locale.US,
                                    "%s OK rssi=%d Tin=%.1f Hin=%.1f Tex=%.1f Hex=%.1f pkt=%d",
                                    devType.toUpperCase(Locale.US),
                                    rssi,
                                    j.optDouble("temperature_int"),
                                    j.optDouble("humidity_int"),
                                    j.optDouble("temperature_ext"),
                                    j.optDouble("humidity_ext"),
                                    j.optInt("packet_counter", -1)));
                        }

                    } catch (Throwable t) {
                        Log.e(TAG, "handleOne", t);
                    }
                }
            };

            // Writer-Thread: schreibt stets die *zwei* letzten Punkte (controller + sensor)
            Thread writer = new Thread(() -> {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                try {
                    while (running) {
                        Thread.sleep(WRITE_MS);

                        JSONArray out = null;
                        synchronized (lock) {
                            if (!lastSeenByType.isEmpty()) {
                                out = new JSONArray();
                                // Reihenfolge fix: erst Controller, dann Sensor (falls vorhanden)
                                JSONObject ctrl = lastSeenByType.get("controller");
                                if (ctrl != null) out.put(ctrl);
                                JSONObject sens = lastSeenByType.get("sensor");
                                if (sens != null) out.put(sens);
                            }
                        }
                        if (out == null) continue;

                        File tmp = new File(outFile.getAbsolutePath() + ".tmp");
                        try (FileOutputStream fos = new FileOutputStream(tmp, false)) {
                            fos.write(out.toString().getBytes());
                            fos.flush();
                        }
                        boolean ok = tmp.renameTo(outFile);
                        if (DEBUG) Log.d(TAG, "JSON flush (" + out.length() + " devices) rename=" + ok);
                    }
                } catch (Throwable th) {
                    Log.e(TAG, "writer", th);
                }
            });
            writer.start();

            scanner.startScan(filters, settings, callback);
            Log.i(TAG, "RUNNING – fast dual scan active");
            return "OK:RUNNING";

        } catch (Throwable t) {
            running = false;
            Log.e(TAG, "start", t);
            return "ERR:" + t.getMessage();
        }
    }

    public static String stop() {
        try {
            if (!running) return "NOT_RUNNING";
            running = false;
            if (scanner != null && callback != null) {
                try { scanner.stopScan(callback); } catch (Throwable ignored) {}
            }
            Log.i(TAG, "STOPPED");
            return "OK:STOPPED";
        } catch (Throwable t) {
            Log.e(TAG, "stop", t);
            return "ERR:" + t.getMessage();
        }
    }

    // -----------------------------------------------------------
    // Klassifizierung & Decoder
    // -----------------------------------------------------------
    private static String classify(String name, String mac) {
        // Controller sendet oft ohne LocalName → treat as controller
        if (name.contains("VSCTLE") || name.isEmpty()) return "controller";
        if (name.contains("ThermoBeacon")) return "sensor";
        // Fallback: unbekannt → mischen wir NICHT ein
        return "unknown";
    }

    private static JSONObject decodePayload(String name, String mac, int rssi, byte[] payload, String devType) {
        try {
            if (payload == null) return null;

            // MSD auf 0x19 0x00 normalisieren
            byte[] msd;
            if (payload.length >= 2 && ((payload[0] & 0xFF) == 0x19) && ((payload[1] & 0xFF) == 0x00)) {
                msd = payload;
            } else {
                msd = new byte[payload.length + 2];
                msd[0] = 0x19;
                msd[1] = 0x00;
                System.arraycopy(payload, 0, msd, 2, payload.length);
            }

            if (msd.length < NEED_MIN) return null;

            int pos = 2 + 6 + 2; // nach CID + 6-Byte Header + Dummy-Short
            if (pos + (2 * 4) + 1 > msd.length) return null;

            int ti = le16(msd, pos); pos += 2;
            int hi = le16(msd, pos); pos += 2;
            int te = le16(msd, pos); pos += 2;
            int he = le16(msd, pos); pos += 2;
            int pkt = msd[pos] & 0xFF;

            double T_i = ti / 16.0, H_i = hi / 16.0, T_e = te / 16.0, H_e = he / 16.0;
            if (!(T_i >= -40 && T_i <= 85 && T_e >= -40 && T_e <= 85 && H_i >= 0 && H_i <= 110 && H_e >= 0 && H_e <= 110))
                return null;

            if (!devType.equals("controller") && !devType.equals("sensor"))
                return null; // unbekannte Devices nicht in die JSON mischen

            JSONObject o = new JSONObject();
            o.put("timestamp", ts());
            o.put("type", devType);
            o.put("name", name);
            o.put("address", mac);
            o.put("rssi", rssi);
            o.put("temperature_int", T_i);
            o.put("humidity_int", H_i);
            o.put("temperature_ext", T_e);
            o.put("humidity_ext", H_e);
            o.put("packet_counter", pkt);
            return o;

        } catch (Throwable t) {
            Log.e(TAG, "decodePayload", t);
            return null;
        }
    }

    // -----------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------
    private static int le16(byte[] a, int off) {
        return ((a[off + 1] & 0xFF) << 8) | (a[off] & 0xFF);
    }

    private static String ts() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new java.util.Date());
    }
}
