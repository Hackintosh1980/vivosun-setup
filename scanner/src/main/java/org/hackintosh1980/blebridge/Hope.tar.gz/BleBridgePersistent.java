package org.hackintosh1980.blebridge;

import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.util.Log;
import android.util.SparseArray;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * BleBridgePersistent – Dual support VSCTLE42A + ThermoBeacon2
 * --------------------------------------------------------------
 * - erkennt beide Typen (0x0019 CompanyID / unbenannte VSCTLE-Variante)
 * - hält alle zuletzt gesehenen Geräte im Speicher
 * - schreibt ble_scan.json mit ALLEN aktiven Geräten
 * - schreibt alle 250 ms neu, mit debug-Logs
 */
public class BleBridgePersistent {

    private static final String TAG = "BleBridgePersistent";
    private static final boolean DEBUG = true;

    private static volatile boolean running = false;
    private static BluetoothLeScanner scanner;
    private static ScanCallback callback;
    private static File outFile;

    private static final List<JSONObject> buf = new ArrayList<>();
    private static final Object lock = new Object();

    // Fine tuning
    private static final int RSSI_MIN = -95;
    private static final int COMPANY_ID = 0x0019;            // VIVOSUN / ThermoBeacon
    private static final int NEED_MIN = 2 + 6 + 2 + (2 * 4) + 1;
    private static final long WRITE_MS = 250L;
    private static final long THROTTLE_MS = 100L;
    private static long lastAppend = 0;

    // --------------------------------------------------------------------
    // Start / Stop API
    // --------------------------------------------------------------------
    public static String start(Context ctx, String outFileName) {
        try {
            if (running) return "ALREADY_RUNNING";
            running = true;

            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = bm != null ? bm.getAdapter() : null;
            if (adapter == null || !adapter.isEnabled()) {
                running = false;
                return "BT_OFF";
            }

            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) {
                running = false;
                return "NO_SCANNER";
            }

            outFile = new File(ctx.getFilesDir(), outFileName);
            if (DEBUG) Log.i(TAG, "Start → file=" + outFile.getAbsolutePath());

            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .setReportDelay(300)
                    .build();

            callback = new ScanCallback() {
                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    for (ScanResult r : results) handle(r);
                }

                @Override
                public void onScanResult(int type, ScanResult r) {
                    handle(r);
                }

                @Override
                public void onScanFailed(int errorCode) {
                    Log.e(TAG, "onScanFailed code=" + errorCode);
                }

                private void handle(ScanResult r) {
                    try {
                        if (r == null || r.getDevice() == null) return;

                        String name = r.getDevice().getName();
                        if (name == null) name = "";
                        String mac = r.getDevice().getAddress();
                        int rssi = r.getRssi();
                        if (rssi < RSSI_MIN) return;

                        ScanRecord rec = r.getScanRecord();
                        if (rec == null) return;

                        SparseArray<byte[]> md = rec.getManufacturerSpecificData();
                        byte[] payload = null;
                        if (md != null) {
                            payload = md.get(COMPANY_ID);
                            if (payload == null && md.size() > 0) {
                                int best = 0;
                                for (int i = 0; i < md.size(); i++) {
                                    byte[] v = md.valueAt(i);
                                    if (v != null && v.length > best) {
                                        best = v.length;
                                        payload = v;
                                    }
                                }
                            }
                        }

                        boolean looksLikeSensor = name.contains("VSCTLE") || name.contains("ThermoBeacon");
                        if (payload == null && !looksLikeSensor) return;

                        long now = System.currentTimeMillis();
                        if (now - lastAppend < THROTTLE_MS) return;
                        lastAppend = now;

                        // RAW-Block
                        if (payload != null && payload.length > 0) {
                            JSONObject raw = new JSONObject();
                            raw.put("timestamp", ts());
                            raw.put("name", name);
                            raw.put("address", mac);
                            raw.put("rssi", rssi);
                            raw.put("manufacturer_data_hex", normalizeMsdHex(payload));
                            raw.put("source", "raw");
                            synchronized (lock) { buf.add(raw); }
                            if (DEBUG) Log.d(TAG, "RAW_HEX " + normalizeMsdHex(payload) + " name=" + name + " rssi=" + rssi);
                        }

                        // Dekodieren
                        if (payload != null && payload.length > 0) {
                            List<JSONObject> decoded = decodeThermoBeacon(name, mac, rssi, payload);
                            for (JSONObject j : decoded) {
                                synchronized (lock) { buf.add(j); }
                                if (DEBUG) {
                                    Log.i(TAG, String.format(Locale.US,
                                            "DECODE_OK %s rssi=%d Tin=%.1f Hin=%.1f Tex=%.1f Hex=%.1f pkt=%d",
                                            name, rssi,
                                            j.optDouble("temperature_int"),
                                            j.optDouble("humidity_int"),
                                            j.optDouble("temperature_ext"),
                                            j.optDouble("humidity_ext"),
                                            j.optInt("packet_counter", -1)));
                                }
                            }
                        }

                    } catch (Throwable t) {
                        Log.e(TAG, "handle", t);
                    }
                }
            };

            // Writer mit persistentem Geräte-Cache
            Thread writer = new Thread(() -> {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                try {
                    Map<String, JSONObject> lastPerAddr = new HashMap<>();
                    while (running) {
                        Thread.sleep(WRITE_MS);
                        List<JSONObject> snap;
                        synchronized (lock) {
                            if (buf.isEmpty()) continue;
                            snap = new ArrayList<>(buf);
                            buf.clear();
                        }

                        for (JSONObject j : snap) {
                            String addr = j.optString("address", "");
                            if (!addr.isEmpty()) lastPerAddr.put(addr, j);
                        }

                        JSONArray arr = new JSONArray();
                        for (JSONObject j : lastPerAddr.values()) arr.put(j);

                        File tmp = new File(outFile.getAbsolutePath() + ".tmp");
                        try (FileOutputStream fos = new FileOutputStream(tmp, false)) {
                            fos.write(arr.toString().getBytes());
                            fos.flush();
                        }
                        boolean ok = tmp.renameTo(outFile);
                        if (DEBUG) Log.d(TAG, "JSON flush (" + arr.length() + " devices) rename=" + ok);
                    }
                } catch (Throwable th) {
                    Log.e(TAG, "writer", th);
                }
            });
            writer.start();

            scanner.startScan(null, settings, callback);
            if (DEBUG) Log.i(TAG, "RUNNING – low-latency scan active");
            return "OK:RUNNING";

        } catch (Throwable t) {
            running = false;
            Log.e(TAG, "start", t);
            return "ERR:" + t.getMessage();
        }
    }

    public static String stop() {
        try {
            if (!running) return "NOT_RUNNING";
            running = false;
            if (scanner != null && callback != null) {
                try { scanner.stopScan(callback); } catch (Throwable ignored) {}
            }
            Log.i(TAG, "STOPPED");
            return "OK:STOPPED";
        } catch (Throwable t) {
            Log.e(TAG, "stop", t);
            return "ERR:" + t.getMessage();
        }
    }

    // --------------------------------------------------------------------
    // Decoder
    // --------------------------------------------------------------------
    private static List<JSONObject> decodeThermoBeacon(String name, String mac, int rssi, byte[] payload) {
        List<JSONObject> out = new ArrayList<>();
        try {
            if (payload == null || payload.length == 0) return out;
            byte[] msd;
            if (payload.length >= 2 && payload[0] == 0x19 && payload[1] == 0x00) {
                msd = payload;
            } else {
                msd = new byte[payload.length + 2];
                msd[0] = 0x19;
                msd[1] = 0x00;
                System.arraycopy(payload, 0, msd, 2, payload.length);
            }
            if (msd.length < NEED_MIN) return out;

            int pos = 2 + 6 + 2;
            while (pos + (2 * 4) + 1 <= msd.length) {
                int ti_raw = le16(msd, pos); pos += 2;
                int hi_raw = le16(msd, pos); pos += 2;
                int te_raw = le16(msd, pos); pos += 2;
                int he_raw = le16(msd, pos); pos += 2;
                int pkt = msd[pos++] & 0xFF;

                double ti = ti_raw / 16.0;
                double hi = hi_raw / 16.0;
                double te = te_raw / 16.0;
                double he = he_raw / 16.0;

                if (ti < -40 || ti > 85 || te < -40 || te > 85 || hi < 0 || hi > 110 || he < 0 || he > 110)
                    continue;

                JSONObject j = new JSONObject();
                j.put("timestamp", ts());
                j.put("name", name);
                j.put("address", mac);
                j.put("rssi", rssi);
                j.put("temperature_int", ti);
                j.put("humidity_int", hi);
                j.put("temperature_ext", te);
                j.put("humidity_ext", he);
                j.put("packet_counter", pkt);
                j.put("source", "thermobeacon");
                out.add(j);
            }
        } catch (Throwable e) {
            Log.w(TAG, "decodeThermoBeacon", e);
        }
        return out;
    }

    // --------------------------------------------------------------------
    // Helpers
    // --------------------------------------------------------------------
    private static int le16(byte[] a, int off) {
        return ((a[off + 1] & 0xFF) << 8) | (a[off] & 0xFF);
    }

    private static String ts() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(new Date());
    }

    private static String normalizeMsdHex(byte[] p) {
        StringBuilder sb = new StringBuilder();
        sb.append("1900");
        for (byte b : p) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }
}
