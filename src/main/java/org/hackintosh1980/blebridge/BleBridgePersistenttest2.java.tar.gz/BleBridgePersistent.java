package org.hackintosh1980.blebridge;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.util.SparseArray;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * BleBridgePersistent – Hybrid Edition (kompilierbar)
 * - Scan-Zyklen (SCAN_WINDOW_MS on / PAUSE_MS off)
 * - Writer-Thread flush -> atomisch (.tmp -> rename)
 * - Decoder kompatibel mit Thermo/Vivosun style frames (1/16)
 *
 * © 2025 Dominik Rosenthal (Hackintosh1980)
 */
public class BleBridgePersistent {

    private static final String TAG = "BleBridgePersistent";

    // state
    private static volatile boolean running = false;

    // scanner
    private static BluetoothLeScanner scanner;
    private static ScanCallback scanCallback;

    // output
    private static File outFile;

    // writer buffer (thread-safe access via bufferLock)
    private static final List<JSONObject> buffer = new ArrayList<>();
    private static final Object bufferLock = new Object();

    // threads
    private static Thread cycleThread = null;
    private static Thread writerThread = null;

    // config
    private static final long SCAN_WINDOW_MS = 25_000L;
    private static final long PAUSE_MS = 700L;
    private static final long WRITE_INTERVAL_MS = 1000L;
    private static final int MIN_PAYLOAD_LEN = 14;
    private static volatile long lastWriteTs = 0L;

    // ---------------- utils ----------------
    private static String bytesToHex(byte[] b) {
        if (b == null) return "null";
        final char[] HEX = "0123456789ABCDEF".toCharArray();
        char[] out = new char[b.length * 2];
        for (int i = 0; i < b.length; i++) {
            int v = b[i] & 0xFF;
            out[i * 2] = HEX[v >>> 4];
            out[i * 2 + 1] = HEX[v & 0x0F];
        }
        return new String(out);
    }

    private static void writeJsonAtomically(JSONArray arr) {
        try {
            File tmp = new File(outFile.getAbsolutePath() + ".tmp");
            try (FileOutputStream fos = new FileOutputStream(tmp, false)) {
                fos.write(arr.toString().getBytes());
                fos.flush();
            }
            if (!tmp.renameTo(outFile)) {
                Log.w(TAG, "Rename tmp->out failed");
            }
        } catch (Exception e) {
            Log.e(TAG, "JSON write failed", e);
        }
    }

    // parse manufacturer payload into JSONObject or null if invalid
    private static JSONObject parsePayload(String name, String mac, int rssi, byte[] payload) {
        try {
            if (payload == null || payload.length < MIN_PAYLOAD_LEN) return null;

            ByteBuffer bb = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
            int base = bb.position();
            if (bb.remaining() >= 6) bb.position(base + 6); // common header skip
            if (bb.remaining() >= 2) bb.getShort(); // optional dummy/counter

            float t_int = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16.0f) : 0f;
            float h_int = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16.0f) : 0f;
            float t_ext = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16.0f) : 0f;
            float h_ext = (bb.remaining() >= 2) ? ((bb.getShort() & 0xFFFF) / 16.0f) : 0f;
            int batt = (bb.remaining() > 0) ? (bb.get() & 0xFF) : -1;

            // Plausibility: internal temp/humidity must be reasonable
            if (t_int < -20f || t_int > 70f) return null;
            if (h_int <= 0f || h_int > 100f) return null;

            JSONObject o = new JSONObject();
            o.put("name", name == null ? "" : name);
            o.put("address", mac == null ? "" : mac);
            o.put("rssi", rssi);
            o.put("temperature_int", t_int);
            o.put("humidity_int", h_int);
            o.put("temperature_ext", t_ext);
            o.put("humidity_ext", h_ext);
            o.put("battery", batt);
            return o;
        } catch (Exception e) {
            Log.w(TAG, "parsePayload error: " + e.getMessage());
            return null;
        }
    }

    // ---------------- API ----------------
    public static String start(Context ctx, String outFileName) {
        try {
            if (running) return "ALREADY_RUNNING";
            running = true;

            Log.i(TAG, "Initialize bridge...");

            BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bm == null) { running = false; return "NO_BT_MANAGER"; }
            BluetoothAdapter adapter = bm.getAdapter();
            if (adapter == null) { running = false; return "NO_ADAPTER"; }
            if (!adapter.isEnabled()) { running = false; return "BT_OFF"; }

            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { running = false; return "NO_SCANNER"; }

            outFile = new File(ctx.getFilesDir(), outFileName);

            // define scan callback
            scanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    try {
                        if (result == null || result.getDevice() == null) return;

                        String name = result.getDevice().getName();
                        String addr = result.getDevice().getAddress();
                        int rssi = result.getRssi();

                        if (result.getScanRecord() != null) {
                            SparseArray<byte[]> mdata = result.getScanRecord().getManufacturerSpecificData();
                            if (mdata != null) {
                                for (int i = 0; i < mdata.size(); i++) {
                                    int cid = mdata.keyAt(i);
                                    byte[] payload = mdata.valueAt(i);
                                    if (payload == null) continue;

                                    Log.d(TAG, "RAW cid=0x" + Integer.toHexString(cid) +
                                            " len=" + payload.length + " hex=" + bytesToHex(payload));

                                    JSONObject parsed = parsePayload(name, addr, rssi, payload);
                                    if (parsed != null) {
                                        synchronized (bufferLock) {
                                            buffer.add(parsed);
                                        }
                                        Log.i(TAG, String.format(
                                                "PARSED %s rssi=%d Tin=%.1f Hin=%.1f Tex=%.1f Hex=%.1f batt=%d",
                                                (name == null ? addr : name),
                                                rssi,
                                                parsed.optDouble("temperature_int", 0.0),
                                                parsed.optDouble("humidity_int", 0.0),
                                                parsed.optDouble("temperature_ext", 0.0),
                                                parsed.optDouble("humidity_ext", 0.0),
                                                parsed.optInt("battery", -1)
                                        ));
                                    } else {
                                        Log.v(TAG, "Ignored invalid/partial frame from " + (name != null ? name : addr));
                                    }
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "onScanResult error", e);
                    }
                }

                @Override
                public void onScanFailed(int errorCode) {
                    Log.e(TAG, "scan failed: " + errorCode);
                }
            };

            // writer thread: flush buffer -> file atomically every WRITE_INTERVAL_MS
            writerThread = new Thread(() -> {
                try {
                    while (running) {
                        try { Thread.sleep(WRITE_INTERVAL_MS); } catch (InterruptedException ignore) {}
                        List<JSONObject> snapshot = null;
                        synchronized (bufferLock) {
                            if (buffer.isEmpty()) continue;
                            snapshot = new ArrayList<>(buffer);
                            buffer.clear();
                        }
                        JSONArray arr = new JSONArray();
                        for (JSONObject j : snapshot) arr.put(j);
                        writeJsonAtomically(arr);
                        lastWriteTs = System.currentTimeMillis();
                        Log.d(TAG, "JSON write flushed (" + arr.length() + " items)");
                    }
                } catch (Throwable t) {
                    Log.e(TAG, "Writer thread error", t);
                }
            }, "ble-json-writer");
            writerThread.start();

            // cycle thread: repeated startScan -> run window -> stopScan -> pause
            cycleThread = new Thread(() -> {
                try {
                    while (running) {
                        try {
                            // start scan (stable method)
                            try {
                                scanner.startScan(scanCallback);
                                Log.i(TAG, "Scan started (window " + SCAN_WINDOW_MS + " ms)");
                            } catch (Exception e) {
                                Log.e(TAG, "startScan failed", e);
                                Thread.sleep(PAUSE_MS);
                                continue;
                            }

                            long start = System.currentTimeMillis();
                            while (running && System.currentTimeMillis() - start < SCAN_WINDOW_MS) {
                                try { Thread.sleep(200); } catch (InterruptedException ie) { /* ignore */ }
                            }

                            try {
                                scanner.stopScan(scanCallback);
                                Log.i(TAG, "Scan stopped (pause " + PAUSE_MS + " ms)");
                            } catch (Exception e) {
                                Log.w(TAG, "stopScan failed", e);
                            }

                            try { Thread.sleep(PAUSE_MS); } catch (InterruptedException ie) { /* ignore */ }

                        } catch (Throwable t) {
                            Log.e(TAG, "Cycle thread loop error", t);
                        }
                    }
                } catch (Throwable outer) {
                    Log.e(TAG, "Cycle thread outer error", outer);
                } finally {
                    try { if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback); } catch (Exception ignore) {}
                    Log.i(TAG, "Cycle thread exiting");
                }
            }, "ble-scan-cycle");
            cycleThread.start();

            Log.i(TAG, "BleBridgePersistent running, writing to " + outFile.getAbsolutePath());
            return "OK:RUNNING";

        } catch (Throwable t) {
            running = false;
            Log.e(TAG, "start error", t);
            return "ERR:" + t.getMessage();
        }
    }

    public static String stop() {
        try {
            if (!running) return "NOT_RUNNING";
            running = false;
            try { if (cycleThread != null) cycleThread.interrupt(); } catch (Throwable ignore) {}
            try { if (writerThread != null) writerThread.interrupt(); } catch (Throwable ignore) {}
            try { if (scanner != null && scanCallback != null) scanner.stopScan(scanCallback); } catch (Throwable ignore) {}
            Log.i(TAG, "BleBridgePersistent stopped");
            return "OK:STOPPED";
        } catch (Throwable t) {
            Log.e(TAG, "stop error", t);
            return "ERR:" + t.getMessage();
        }
    }
}
