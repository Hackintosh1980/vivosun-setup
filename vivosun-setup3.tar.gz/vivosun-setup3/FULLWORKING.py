from kivy.app import App
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.core.window import Window
from jnius import autoclass
import json, os, time

# -------------------------------
# Fensterdesign
# -------------------------------
Window.clearcolor = (0, 0, 0, 1)

SCAN_DURATION_MS = 3000     # 3 Sekunden aktiv scannen
SCAN_INTERVAL_SEC = 20      # alle 20 Sekunden wiederholen
JSON_PATH = "/data/user/0/org.hackintosh1980.vivosunreader/files/ble_scan.json"

class BridgeApp(App):

    def build(self):
        self.label = Label(
            text="[b]VIVOSUN Live-Bridge[/b]\nStarte ersten Scan…",
            markup=True,
            font_size="26sp",
            halign="center",
            valign="middle",
            color=(0, 1, 1, 1)
        )
        # Start nach 1 Sekunde
        Clock.schedule_once(self.start_scan, 1)
        # Wiederholung
        Clock.schedule_interval(self.start_scan, SCAN_INTERVAL_SEC)
        return self.label

    # -------------------------------
    # Scan-Vorgang
    # -------------------------------
    def start_scan(self, *args):
        try:
            ctx = autoclass("org.kivy.android.PythonActivity").mActivity
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")

            start = time.strftime("%H:%M:%S")
            self.label.text = f"[color=#00ffaa][b]Scanning…[/b][/color]\n({start})"

            result = BleBridge.scan(ctx, SCAN_DURATION_MS, "ble_scan.json")

            # Nach dem Scan Daten anzeigen
            Clock.schedule_once(self.update_display, 0.5)

        except Exception as e:
            self.label.text = f"[color=#ff5555]Bridge-Fehler:[/color] {e}"

    # -------------------------------
    # Anzeige aktualisieren
    # -------------------------------
    def update_display(self, *args):
        if not os.path.exists(JSON_PATH):
            self.label.text = f"[color=#ffaa00]Keine Datei gefunden![/color]\n{JSON_PATH}"
            return

        try:
            with open(JSON_PATH) as f:
                data = json.load(f)
            if not data:
                self.label.text = "[color=#ff5555]Keine Sensordaten gefunden[/color]"
                return

            d = data[0]
            addr = d.get("address", "?")
            name = d.get("name", "?")
            rssi = d.get("rssi", "?")
            batt = d.get("battery", "?")

            t_int = d.get("temperature_int", 0.0)
            t_ext = d.get("temperature_ext", 0.0)
            h_int = d.get("humidity_int", 0.0)
            h_ext = d.get("humidity_ext", 0.0)

            now = time.strftime("%H:%M:%S")

            self.label.text = (
                f"[b][color=#00ffaa]VIVOSUN Live-Bridge[/color][/b]\n"
                f"[size=18sp][color=#aaaaaa]{name}[/color]  [b]{addr}[/b][/size]\n"
                f"[color=#00ccff]RSSI {rssi} dBm[/color]   "
                f"[color=#999999]{now}[/color]\n\n"
                f"[color=#ff6666]Innen {t_int:.1f} °C[/color]   "
                f"[color=#66ccff]Aussen {t_ext:.1f} °C[/color]\n"
                f"[color=#99ff99]rLF in {h_int:.1f}%[/color]   "
                f"[color=#99ccff]rLF out {h_ext:.1f}%[/color]\n\n"
                f"[color=#ffff66]🔋 {batt}%[/color]"
            )

        except Exception as e:
            self.label.text = f"[color=#ff5555]JSON-Fehler:[/color] {e}"

# -------------------------------
# App-Start
# -------------------------------
if __name__ == "__main__":
    BridgeApp().run()
