#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VIVOSUN Realtime Reader – Android Bridge Version 🌡💧🔋
Liest über org.hackintosh1980.blebridge.BleBridge echte Sensordaten (Temp, RH, Batt)
und zeigt sie live im Vollbild an.
"""

import os, json, time
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle
from kivy.utils import platform


BRIDGE_FILE = "ble_scan.json"
SCAN_INTERVAL = 4.0     # Sekunden pro Scan
SCAN_DURATION = 2000     # Millisekunden für BleBridge.scan()


class RealtimeReader(App):
    def build(self):
        self.root = BoxLayout(orientation="vertical", padding=20, spacing=15)
        self.labels = {}

        # Hintergrundfarbe
        with self.root.canvas.before:
            Color(0.05, 0.1, 0.1, 1)
            self.rect = Rectangle(size=self.root.size, pos=self.root.pos)
        self.root.bind(size=self._update_rect, pos=self._update_rect)

        # Titel
        self.lbl_title = Label(
            text="🌿 VIVOSUN Live-Bridge", font_size="28sp", color=(0, 1, 0.8, 1), size_hint_y=None, height=60
        )
        self.root.add_widget(self.lbl_title)

        # Sensorwerte (groß)
        for key, symbol, unit, color in [
            ("temperature", "🌡", "°C", (1, 0.4, 0.4, 1)),
            ("humidity", "💧", "%", (0.4, 0.8, 1, 1)),
            ("battery", "🔋", "%", (0.8, 1, 0.4, 1)),
        ]:
            lbl = Label(text=f"{symbol} — {unit}", font_size="48sp", color=color)
            self.labels[key] = lbl
            self.root.add_widget(lbl)

        self.lbl_status = Label(text="⏳ Initialisiere BLE-Bridge...", font_size="20sp", color=(1, 1, 1, 0.8))
        self.root.add_widget(self.lbl_status)

        # Android-Bridge vorbereiten
        if platform == "android":
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            self.BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            self.activity = PythonActivity.mActivity
            self.lbl_status.text = "✅ Android-Bridge bereit"
            Clock.schedule_interval(self.update_reading, SCAN_INTERVAL)
        else:
            self.lbl_status.text = "🖥 Desktop-Test (kein BLE)"

        return self.root

    def _update_rect(self, *_):
        self.rect.pos = self.root.pos
        self.rect.size = self.root.size

    def update_reading(self, *_):
        """ruft die Bridge auf und zeigt die Werte an"""
        try:
            self.lbl_status.text = "🔄 Scanne..."
            resp = self.BleBridge.scan(self.activity, SCAN_DURATION, BRIDGE_FILE)
            print("Bridge Response:", resp)

            path = f"{self.activity.getFilesDir().getAbsolutePath()}/{BRIDGE_FILE}"
            if not os.path.exists(path):
                self.lbl_status.text = "⚠️ Keine Datei"
                return

            with open(path, "r") as f:
                arr = json.load(f)
            if not arr:
                self.lbl_status.text = "⚠️ Keine Geräte"
                return

            # Nimm das erste Gerät mit Werten
            dev = None
            for d in arr:
                if "temperature" in d or "humidity" in d:
                    dev = d
                    break

            if not dev:
                self.lbl_status.text = "⚠️ Keine Sensordaten im Scan"
                return

            t = dev.get("temperature")
            h = dev.get("humidity")
            b = dev.get("battery")

            # UI-Update
            if t is not None:
                self.labels["temperature"].text = f"🌡 {t:.2f} °C"
            if h is not None:
                self.labels["humidity"].text = f"💧 {h:.2f} %"
            if b is not None:
                self.labels["battery"].text = f"🔋 {b:.0f} %"

            self.lbl_status.text = f"✅ {dev.get('name','Sensor')}  ({dev.get('address','--')})"
            print(f"📡 Werte: T={t}, H={h}, Batt={b}")

        except Exception as e:
            self.lbl_status.text = f"❌ Fehler: {e}"
            print("[ERR]", e)


if __name__ == "__main__":
    RealtimeReader().run()
