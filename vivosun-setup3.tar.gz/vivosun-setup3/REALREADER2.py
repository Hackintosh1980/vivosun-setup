#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# main.py – Live-Bridge Inspector (Anzeige + Rohdaten-Log)

import os, json, time, math
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.utils import platform

TARGET_MAC = "F0:F1:00:00:06:19".upper()
BRIDGE_OUT = "ble_scan.json"   # von BleBridge.java
DATA_DIR   = "data"

def ensure_files_dir():
    if platform == "android":
        from jnius import autoclass
        return autoclass("org.kivy.android.PythonActivity").mActivity.getFilesDir().getAbsolutePath()
    return os.getcwd()

def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f: json.dump(obj, f, indent=2)

def plausible_temp(t):
    return t is not None and -20.0 <= t <= 60.0

def plausible_hum(h):
    return h is not None and 0.0 <= h <= 100.0

def plausible_batt(b):
    return b is not None and 0 <= b <= 100

class LiveBridge(App):
    def build(self):
        self.files_dir = ensure_files_dir()
        self.out_file  = os.path.join(self.files_dir, BRIDGE_OUT)
        self.data_dir  = os.path.join(self.files_dir, DATA_DIR)
        os.makedirs(self.data_dir, exist_ok=True)

        root = BoxLayout(orientation="vertical", padding=18, spacing=10)
        self.head = Label(text="VIVOSUN Live-Bridge", font_size=44, color=(0,1,0.8,1))
        root.add_widget(self.head)

        self.lbl_t = Label(text="— °C", font_size=96, color=(1,0.35,0.35,1))
        self.lbl_h = Label(text="— %",  font_size=96, color=(0.45,0.7,1,1))
        self.lbl_b = Label(text="— %",  font_size=80,  color=(0.9,1,0.4,1))
        root.add_widget(self.lbl_t); root.add_widget(self.lbl_h); root.add_widget(self.lbl_b)

        self.footer = Label(text="(kein Gerät)", font_size=28, color=(0.8,0.8,0.85,1))
        root.add_widget(self.footer)

        # alle 3s: Bridge aufrufen + Datei auswerten
        Clock.schedule_interval(self._tick, 3.0)
        return root

    def _run_bridge(self):
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            act = PythonActivity.mActivity
            # alte Datei löschen
            try:
                if os.path.exists(self.out_file): os.remove(self.out_file)
            except Exception: pass
            resp = BleBridge.scan(act, 2000, BRIDGE_OUT)
            print("🟢 Bridge Response:", resp)
        except Exception as e:
            print("❌ Bridge err:", e)

    def _tick(self, *_):
        if platform == "android":
            self._run_bridge()

        # kleine Wartezeit, dann lesen
        t0 = time.time()
        while time.time()-t0 < 2.5:
            if os.path.exists(self.out_file) and os.path.getsize(self.out_file) > 2:
                break
            time.sleep(0.1)

        if not os.path.exists(self.out_file):
            self.footer.text = "Keine Bridge-Datei"
            return

        try:
            with open(self.out_file, "r") as f:
                arr = json.load(f)
        except Exception as e:
            self.footer.text = f"JSON-Fehler: {e}"
            return

        hit = None
        raws = None
        for dev in arr if isinstance(arr, list) else []:
            if (dev.get("address","").upper() == TARGET_MAC):
                hit = dev
                # Rohes Werbematerial sichern
                raws = {
                    "mfg_data": dev.get("mfg_data", []),
                    "service_uuids": dev.get("service_uuids", []),
                    "service_data": dev.get("service_data", []),
                    "rssi": dev.get("rssi"),
                    "tx_power": dev.get("tx_power")
                }
                save_json(os.path.join(self.data_dir, "adv_raw.json"), raws)
                break

        if not hit:
            self.lbl_t.text = "— °C"
            self.lbl_h.text = "— %"
            self.lbl_b.text = "— %"
            self.footer.text = "Zielgerät nicht gefunden"
            return

        # 1) Direktfelder nutzen, wenn vorhanden + plausibel (falls Hersteller schon temp/hum mitliefert)
        t = hit.get("temperature")
        h = hit.get("humidity")
        b = hit.get("battery")

        # Plausibilität
        self.lbl_t.text = f"{t:.2f} °C" if plausible_temp(t) else "— °C"
        self.lbl_h.text = f"{h:.2f} %"  if plausible_hum(h) else "— %"
        self.lbl_b.text = f"{b:.0f} %"  if plausible_batt(b) else "— %"
        self.footer.text = f"{hit.get('name','?')}  ({hit.get('address','?')})"

if __name__ == "__main__":
    LiveBridge().run()
