#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VIVOSUN Setup – Bridge-Scanner mit Statusanzeige & Geräteliste
Stabiler BLE-Scan via Java-Bridge (Android 10+)
"""

import json, os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.clock import Clock
from kivy.utils import platform

CONFIG_FILE = "config.json"

def safe_write_json(path, data):
    try:
        with open(path, "w") as f: json.dump(data, f, indent=2)
    except Exception: pass

class VivosunBridgeApp(App):
    def build(self):
        root = BoxLayout(orientation="vertical", padding=10, spacing=10)
        self.status = Label(text="⏳ Initialisiere...", size_hint_y=None, height=40)
        root.add_widget(self.status)

        # Scrollbare Geräte-Liste
        self.scroll = ScrollView(size_hint=(1, 0.8))
        self.device_layout = GridLayout(cols=1, spacing=6, size_hint_y=None)
        self.device_layout.bind(minimum_height=self.device_layout.setter("height"))
        self.scroll.add_widget(self.device_layout)
        root.add_widget(self.scroll)

        # Scan-Button
        self.btn_scan = Button(text="🔍 Scan BLE (Bridge)",
                               size_hint_y=None, height=60,
                               background_color=(0.2,0.6,1,1),
                               on_release=lambda *_: Clock.schedule_once(lambda __: self.run_scan(), 0))
        root.add_widget(self.btn_scan)

        return root

    def on_start(self):
        if platform == "android":
            Clock.schedule_once(lambda dt: self.check_bt_state(), 0.5)

    def check_bt_state(self):
        """Zeigt an, ob Bluetooth aktiv ist"""
        try:
            from jnius import autoclass
            BluetoothAdapter = autoclass('android.bluetooth.BluetoothAdapter')
            adapter = BluetoothAdapter.getDefaultAdapter()
            if adapter is None:
                self.status.text = "⚠️ Kein Bluetooth-Adapter"
            elif adapter.isEnabled():
                self.status.text = "✅ Bluetooth: EIN"
            else:
                self.status.text = "🚫 Bluetooth: AUS"
        except Exception as e:
            self.status.text = f"Err BT: {e}"

    def run_scan(self):
        if platform != "android":
            self.status.text = "Nur Android unterstützt"; return
        self.status.text = "🔄 Scanne..."
        self.device_layout.clear_widgets()
        Clock.schedule_once(lambda dt: self._bridge_scan(), 0.3)

    def _bridge_scan(self):
        """ruft Java-Bridge auf"""
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            activity = PythonActivity.mActivity

            out_name = "ble_scan.json"
            resp = BleBridge.scan(activity, 15000, out_name)
            print("🟢 Bridge Response:", resp)

            files_dir = activity.getFilesDir().getAbsolutePath()
            json_path = f"{files_dir}/{out_name}"

            if not os.path.exists(json_path):
                self.status.text = "⚠️ Keine Ergebnisse"
                return

            with open(json_path, "r") as f:
                data = json.load(f)

            n = len(data)
            self.status.text = f"✅ {n} Gerät(e) gefunden"

            for dev in data:
                name = dev.get("name", "unknown")
                addr = dev.get("address", "")
                btn = Button(text=f"{name}  ({addr})",
                             size_hint_y=None, height=44,
                             background_color=(0.1,0.4,0.8,1))
                btn.bind(on_release=lambda x, d=dev: self.save_selected(d))
                self.device_layout.add_widget(btn)

        except Exception as e:
            self.status.text = f"❌ Fehler: {e}"

    def save_selected(self, dev):
        """Speichert Auswahl in config.json"""
        cfg = {"device_id": dev.get("address", ""), "device_name": dev.get("name", "")}
        safe_write_json(CONFIG_FILE, cfg)
        self.status.text = f"💾 Gespeichert: {dev.get('name','?')}"
        print("💾 Saved", cfg)

if __name__ == "__main__":
    VivosunBridgeApp().run()
