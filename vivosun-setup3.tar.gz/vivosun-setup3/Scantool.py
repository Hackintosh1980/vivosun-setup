#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VIVOSUN Bridge Test – stabile Basis
- Android: scannt über BleBridge, zeigt Geräte (Name + MAC)
- Speichern der Auswahl in config.json (im App-Verzeichnis)
- Klare Status-/Fehlerausgabe
"""

import os, json, time
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.utils import platform

CONFIG_FILE = "config.json"
BRIDGE_OUT  = "ble_scan.json"
SCAN_SECS   = 12

def safe_write_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print("write json error:", e)

class BridgeMinimal(App):
    def build(self):
        root = BoxLayout(orientation="vertical", padding=10, spacing=10)

        self.status = Label(text="⏳ Bereit", size_hint_y=None, height=40)
        root.add_widget(self.status)

        self.scroll = ScrollView(size_hint=(1, 0.8))
        self.list_layout = GridLayout(cols=1, spacing=6, size_hint_y=None, padding=4)
        self.list_layout.bind(minimum_height=self.list_layout.setter("height"))
        self.scroll.add_widget(self.list_layout)
        root.add_widget(self.scroll)

        btn_row = BoxLayout(size_hint_y=None, height=56, spacing=8)
        self.btn_scan = Button(text=f"🔍 Scan {SCAN_SECS}s", on_release=lambda *_: self.start_scan())
        self.btn_save = Button(text="💾 Speichern (Auswahl)", disabled=True, on_release=self.save_selected)
        btn_row.add_widget(self.btn_scan)
        btn_row.add_widget(self.btn_save)
        root.add_widget(btn_row)

        self.selected = None
        return root

    def on_start(self):
        if platform == "android":
            # Permissions (klassisch, stabil):
            try:
                from android.permissions import request_permissions, check_permission, Permission
                wanted = [
                    Permission.BLUETOOTH, Permission.BLUETOOTH_ADMIN,
                    Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION,
                    Permission.ACCESS_BACKGROUND_LOCATION
                ]
                missing = [p for p in wanted if not check_permission(p)]
                if missing:
                    request_permissions(missing)
            except Exception as e:
                print("perm err:", e)
            Clock.schedule_once(lambda dt: self._bt_status(), 0.6)
        else:
            self.status.text = "🖥️ Desktop – nur Android scannt."

    def _bt_status(self):
        try:
            from jnius import autoclass
            Adapter = autoclass("android.bluetooth.BluetoothAdapter")
            a = Adapter.getDefaultAdapter()
            if a is None:
                self.status.text = "⚠️ Kein Bluetooth-Adapter"
            elif a.isEnabled():
                self.status.text = "✅ Bluetooth: EIN"
            else:
                self.status.text = "🚫 Bluetooth: AUS"
        except Exception as e:
            self.status.text = f"BT-Check Fehler: {e}"

    def start_scan(self):
        if platform != "android":
            self.status.text = "Nur Android scannt."
            return
        self.btn_scan.disabled = True
        self.btn_save.disabled = True
        self.selected = None
        self.list_layout.clear_widgets()
        self.status.text = f"🔄 Scanne… {SCAN_SECS}s"
        Clock.schedule_once(lambda dt: self._bridge_scan(), 0.2)

    def _bridge_scan(self):
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            BleBridge      = autoclass("org.hackintosh1980.blebridge.BleBridge")
            activity = PythonActivity.mActivity

            files_dir = activity.getFilesDir().getAbsolutePath()
            out_path  = f"{files_dir}/{BRIDGE_OUT}"

            # Vorheriges Ergebnis entfernen
            try:
                if os.path.exists(out_path):
                    os.remove(out_path)
            except Exception:
                pass

            resp = BleBridge.scan(activity, SCAN_SECS * 1000, BRIDGE_OUT)
            print("🟢 Bridge Response:", resp)

            # bis Datei vorhanden ist
            t0 = time.time()
            while time.time() - t0 < 5.0:
                if os.path.exists(out_path) and os.path.getsize(out_path) > 2:
                    break
                time.sleep(0.2)

            if not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
                self.status.text = "⚠️ Keine Ergebnisse"
                self.btn_scan.disabled = False
                return

            with open(out_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            self._show_devices(data)

        except Exception as e:
            self.status.text = f"❌ Scanfehler: {e}"
        finally:
            self.btn_scan.disabled = False
            Clock.schedule_once(lambda dt: self._bt_status(), 0.5)

    def _show_devices(self, devices):
        if not isinstance(devices, list):
            devices = []
        # Nur Anzeige: name + address
        self.list_layout.clear_widgets()
        if not devices:
            self.status.text = "0 Geräte gefunden"
            return

        self.status.text = f"✅ {len(devices)} Gerät(e) gefunden"
        for d in devices:
            name = d.get("name") or "unknown"
            addr = d.get("address") or ""
            btn = Button(text=f"{name}   ({addr})", size_hint_y=None, height=44)
            btn.bind(on_release=lambda x, dev=d: self._select(dev))
            self.list_layout.add_widget(btn)

    def _select(self, dev):
        self.selected = dev
        self.btn_save.disabled = False
        self.status.text = f"✔️ Ausgewählt: {dev.get('name','?')}"

    def save_selected(self, *_):
        if not self.selected:
            self.status.text = "❌ Nichts ausgewählt."
            return
        cfg = {"device_id": self.selected.get("address",""),
               "device_name": self.selected.get("name","")}
        safe_write_json(CONFIG_FILE, cfg)
        self.status.text = f"💾 Gespeichert: {cfg['device_name']} ({cfg['device_id']})"

if __name__ == "__main__":
    BridgeMinimal().run()
