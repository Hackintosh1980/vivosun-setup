from kivy.app import App
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.core.window import Window
from jnius import autoclass
import json, os

Window.clearcolor = (0, 0, 0, 1)

class BridgeApp(App):
    def build(self):
        self.label = Label(
            text="[b]VIVOSUN Live-Bridge[/b]\nStarte Scan...",
            markup=True,
            font_size="28sp",
            halign="center",
            valign="middle",
            color=(0, 1, 1, 1)
        )
        Clock.schedule_once(self.start_scan, 1)
        return self.label

    def start_scan(self, *args):
        try:
            ctx = autoclass("org.kivy.android.PythonActivity").mActivity
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            result = BleBridge.scan(ctx, 5000, "ble_scan.json")
            self.label.text = f"[color=#00ffaa]Bridge: {result}[/color]"
            Clock.schedule_interval(self.update_display, 3)
        except Exception as e:
            self.label.text = f"[color=#ff5555]Bridge Fehler:[/color] {e}"

    def update_display(self, *args):
        path = "/data/user/0/org.hackintosh1980.vivosunreader/files/ble_scan.json"
        if not os.path.exists(path):
            self.label.text = f"[color=#ffaa00]Keine Datei gefunden![/color]\n{path}"
            return

        try:
            with open(path) as f:
                data = json.load(f)
            if not data:
                self.label.text = "[color=#ff5555]Keine Sensordaten gefunden[/color]"
                return

            d = data[0]
            addr = d.get("address", "?")
            name = d.get("name", "?")
            batt = d.get("battery", "?")
            rssi = d.get("rssi", "?")

            t_int = d.get("temperature_int", 0.0)
            t_ext = d.get("temperature_ext", 0.0)
            h_int = d.get("humidity_int", 0.0)
            h_ext = d.get("humidity_ext", 0.0)

            self.label.text = (
                f"[b][color=#00ffaa]VIVOSUN Live-Bridge[/color][/b]\n\n"
                f"[color=#aaaaaa]{name}[/color]  [b]{addr}[/b]\nRSSI {rssi} dBm\n\n"
                f"[color=#ff6666]Innen {t_int:.1f} °C[/color]   "
                f"[color=#66ccff]Aussen {t_ext:.1f} °C[/color]\n"
                f"[color=#99ff99]rLF in {h_int:.1f}%[/color]   "
                f"[color=#99ccff]rLF out {h_ext:.1f}%[/color]\n\n"
                f"[color=#ffff66]🔋 {batt}%[/color]"
            )

        except Exception as e:
            self.label.text = f"[color=#ff5555]JSON-Fehler:[/color] {e}"

if __name__ == "__main__":
    BridgeApp().run()
