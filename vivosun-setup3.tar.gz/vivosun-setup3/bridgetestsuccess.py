#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BleBridge minimaler Funktionstest
Ruft direkt org.hackintosh1980.blebridge.BleBridge.scan(...) auf.
Zeigt Ergebnis + schreibt es nach files/bridge_test.txt
"""

import os, time
from kivy.app import App
from kivy.uix.label import Label
from kivy.utils import platform

class BridgeTestApp(App):
    def build(self):
        self.lbl = Label(text="🚀 Starte Bridge-Test…")
        if platform == "android":
            from jnius import autoclass
            try:
                PythonActivity = autoclass("org.kivy.android.PythonActivity")
                BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
                activity = PythonActivity.mActivity
                self.lbl.text = "🔍 Rufe Bridge.scan() auf…"
                out_name = "ble_scan.json"

                resp = BleBridge.scan(activity, 4000, out_name)
                self.lbl.text = f"🟢 Bridge Response:\n{resp}"

                # Ergebnis zusätzlich speichern
                files_dir = activity.getFilesDir().getAbsolutePath()
                log_path = os.path.join(files_dir, "bridge_test.txt")
                with open(log_path, "w") as f:
                    f.write(str(resp))
                print("📂 Datei-Pfad:", log_path)

            except Exception as e:
                self.lbl.text = f"❌ Bridge-Fehler:\n{e}"
                print(f"[ERR] Bridge-Aufruf: {e}")
        else:
            self.lbl.text = "Nur auf Android testbar."
        return self.lbl


if __name__ == "__main__":
    BridgeTestApp().run()
