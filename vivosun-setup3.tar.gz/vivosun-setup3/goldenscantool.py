#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VIVOSUN Setup – BLE Bridge v3
Android 10 (API 29) – stabiler Scan via Java-Bridge:
- Countdown-Anzeige (konfigurierbar)
- Wartet auf Bridge-Output (Dateiwächter)
- Listet Geräte (Name + Adresse)
- Speichert Auswahl in config.json
"""

import os, json, time
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.utils import platform

CONFIG_FILE = "config.json"
SCAN_SECONDS = 15               # ⏱️ Scan-Dauer anpassen
BRIDGE_OUT = "ble_scan.json"    # Datei, die BleBridge schreibt (getFilesDir())

def safe_write_json(path, data):
    try:
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass

class VivosunBridgeV3(App):
    def build(self):
        root = BoxLayout(orientation="vertical", padding=10, spacing=10)

        # Statuszeile
        self.status = Label(text="⏳ Initialisiere…", size_hint_y=None, height=42)
        root.add_widget(self.status)

        # Geräteliste (scrollbar)
        self.list_scroll = ScrollView(size_hint=(1, 0.75))
        self.list_layout = GridLayout(cols=1, spacing=6, size_hint_y=None, padding=6)
        self.list_layout.bind(minimum_height=self.list_layout.setter("height"))
        self.list_scroll.add_widget(self.list_layout)
        root.add_widget(self.list_scroll)

        # Buttonzeile
        btn_row = BoxLayout(size_hint_y=None, height=60, spacing=10)
        self.btn_scan = Button(text=f"🔍 Scan {SCAN_SECONDS}s", on_release=self.start_scan)
        self.btn_save = Button(text="💾 Speichern (ausgewählt)", disabled=True, on_release=self.save_selected)
        btn_row.add_widget(self.btn_scan)
        btn_row.add_widget(self.btn_save)
        root.add_widget(btn_row)

        self.selected = None
        self._count_ev = None
        self._count_left = 0

        return root

    # --------- Lifecycle ----------
    def on_start(self):
        if platform == "android":
            # Permissions anfragen
            from android.permissions import request_permissions, check_permission, Permission
            wanted = [
                Permission.BLUETOOTH, Permission.BLUETOOTH_ADMIN,
                Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION,
                Permission.ACCESS_BACKGROUND_LOCATION
            ]
            missing = [p for p in wanted if not check_permission(p)]
            if missing:
                request_permissions(missing)

            # BT-Status anzeigen
            Clock.schedule_once(lambda dt: self._update_bt_status(), 0.8)
        else:
            self.status.text = "🖥️ Desktop – Android benötigt."

    def _update_bt_status(self):
        try:
            from jnius import autoclass
            BluetoothAdapter = autoclass('android.bluetooth.BluetoothAdapter')
            a = BluetoothAdapter.getDefaultAdapter()
            if a is None:
                self.status.text = "⚠️ Kein Bluetooth-Adapter"
            elif a.isEnabled():
                self.status.text = "✅ Bluetooth: EIN"
            else:
                self.status.text = "🚫 Bluetooth: AUS (bitte einschalten)"
        except Exception as e:
            self.status.text = f"BT-Check Fehler: {e}"

    # --------- Scan ----------
    def start_scan(self, *_):
        if platform != "android":
            self.status.text = "Nur auf Android scanbar."
            return

        # UI vorbereiten
        self.btn_scan.disabled = True
        self.btn_save.disabled = True
        self.selected = None
        self.list_layout.clear_widgets()

        self._count_left = SCAN_SECONDS
        self.status.text = f"🔄 Scanne… {self._count_left}s"
        # Countdown starten
        self._count_ev = Clock.schedule_interval(self._tick_countdown, 1.0)

        # Scan wirklich starten (Bridge-Aufruf)
        Clock.schedule_once(lambda dt: self._run_bridge_scan(), 0.2)

    def _tick_countdown(self, dt):
        self._count_left -= 1
        if self._count_left <= 0:
            # Countdown endet, aber das Stoppen managt bereits die Bridge
            self.status.text = "🔄 Scanne… (abschließen)"
            Clock.unschedule(self._count_ev)
            self._count_ev = None
        else:
            self.status.text = f"🔄 Scanne… {self._count_left}s"

    def _run_bridge_scan(self):
        """ruft die Java-Bridge auf und wartet anschließend auf Output-Datei"""
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            activity = PythonActivity.mActivity

            # Vor dem Scan: alte Datei löschen (falls vorhanden)
            files_dir = activity.getFilesDir().getAbsolutePath()
            out_path = f"{files_dir}/{BRIDGE_OUT}"
            try:
                if os.path.exists(out_path):
                    os.remove(out_path)
            except Exception:
                pass

            # Scan ausführen (blockiert in Java-Thread – ok)
            resp = BleBridge.scan(activity, SCAN_SECONDS * 1000, BRIDGE_OUT)
            print("🟢 Bridge Response:", resp)

            # Nachlauf: kurze Wartezeit bis Datei geschrieben ist
            t0 = time.time()
            for _ in range(20):  # bis zu ~5s warten
                if os.path.exists(out_path) and os.path.getsize(out_path) > 2:
                    break
                time.sleep(0.25)

            # Datei laden
            if not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
                self.status.text = "⚠️ Keine Ergebnisse (Datei leer/nicht da)"
                self.btn_scan.disabled = False
                return

            with open(out_path, "r") as f:
                try:
                    data = json.load(f)
                except Exception:
                    # Falls unvollständig, noch einmal ganz kurz warten/lesen
                    time.sleep(0.3)
                    with open(out_path, "r") as f2:
                        data = json.load(f2)

            # Ergebnisse anzeigen
            self._show_results(data)

        except Exception as e:
            self.status.text = f"❌ Scanfehler: {e}"
        finally:
            # Countdown sicher stoppen & Button wieder aktiv
            if self._count_ev:
                Clock.unschedule(self._count_ev)
                self._count_ev = None
            self.btn_scan.disabled = False
            # BT-Status aktualisieren
            Clock.schedule_once(lambda dt: self._update_bt_status(), 0.5)

    def _show_results(self, devices_json):
        # Optional filtern (hier schon in Java gefiltert; doppelt hält besser)
        devices = []
        try:
            for d in devices_json:
                name = (d.get("name") or "").strip()
                addr = (d.get("address") or "").strip()
                if not name or not addr:
                    continue
                if ("vivosun" in name.lower()) or ("thermobeacon" in name.lower()):
                    devices.append({"name": name, "address": addr})
        except Exception:
            # Falls JSON keine Liste ist, rohes Objekt ignorieren
            pass

        # Fallback: wenn Filter alles rauswirft, zeige Rohdaten
        if not devices and isinstance(devices_json, list):
            devices = [
                {"name": (d.get("name") or "unknown"), "address": (d.get("address") or "")}
                for d in devices_json if isinstance(d, dict)
            ]

        n = len(devices)
        self.status.text = f"✅ {n} Gerät(e) gefunden"
        self.list_layout.clear_widgets()

        if n == 0:
            # Hinweis fürs Troubleshooting
            tip = Label(text="Tipp: Sensor wecken (Knopf), näher ans Phone, Scanzeit erhöhen", size_hint_y=None, height=40)
            self.list_layout.add_widget(tip)
            return

        for dev in devices:
            txt = f"{dev['name']}  ({dev['address']})"
            b = Button(text=txt, size_hint_y=None, height=46)
            b.bind(on_release=lambda x, d=dev: self._select_device(d))
            self.list_layout.add_widget(b)

    # --------- Auswahl/Speichern ----------
    def _select_device(self, dev):
        self.selected = dev
        self.btn_save.disabled = False
        self.status.text = f"✔️ Ausgewählt: {dev.get('name','?')}"

    def save_selected(self, *_):
        if not self.selected:
            self.status.text = "❌ Kein Gerät ausgewählt."
            return
        cfg = {"device_id": self.selected.get("address",""), "device_name": self.selected.get("name","")}
        safe_write_json(CONFIG_FILE, cfg)
        self.status.text = f"💾 Gespeichert: {cfg['device_name']} ({cfg['device_id']})"

if __name__ == "__main__":
    VivosunBridgeV3().run()
