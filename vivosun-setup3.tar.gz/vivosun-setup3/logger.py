#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, json, time
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.utils import platform

BRIDGE_OUT = "ble_scan.json"

class BridgeHeurApp(App):
    def build(self):
        root = BoxLayout(orientation="vertical", padding=12, spacing=10)
        self.status = Label(text="⏳ Bereit", font_size=20, size_hint_y=None, height=36)
        self.big = Label(text="—", font_size=42)
        self.raw = Label(text="", font_size=16)
        btn = Button(text="🔍 Scan 12s", size_hint_y=None, height=60)
        btn.bind(on_release=lambda *_: self.do_scan(12_000))
        root.add_widget(self.status)
        root.add_widget(self.big)
        root.add_widget(self.raw)
        root.add_widget(btn)
        return root

    def _files_dir(self):
        if platform == "android":
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            return PythonActivity.mActivity.getFilesDir().getAbsolutePath()
        return os.getcwd()

    def do_scan(self, ms):
        self.status.text = "🔄 Scanne…"
        Clock.schedule_once(lambda dt: self._run_bridge(ms), 0.1)

    def _run_bridge(self, ms):
        try:
            from jnius import autoclass
            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            activity = PythonActivity.mActivity

            files_dir = self._files_dir()
            out_path  = os.path.join(files_dir, BRIDGE_OUT)
            try:
                if os.path.exists(out_path): os.remove(out_path)
            except: pass

            resp = BleBridge.scan(activity, ms, BRIDGE_OUT)
            print("BridgeResp:", resp)
            self.status.text = f"Bridge: {resp}"

            t0 = time.time()
            while time.time() - t0 < 3.0:
                if os.path.exists(out_path) and os.path.getsize(out_path) > 2:
                    break
                time.sleep(0.1)

            if not os.path.exists(out_path):
                self.big.text = "❌ Keine Datei"
                return

            data = json.load(open(out_path, "r"))
            if not isinstance(data, list) or not data:
                self.big.text = "❌ Leer"
                return

            # Nimm erstes passendes Gerät und zeige guesses + raw an
            show = []
            for d in data:
                name = d.get("name","?")
                addr = d.get("address","")
                mfg  = d.get("manufacturer_data", [])
                line = f"[b]{name}[/b]  {addr}"
                for md in mfg:
                    t = md.get("temperature_guess")
                    h = md.get("humidity_guess")
                    hx = md.get("hex","")
                    if t is not None or h is not None:
                        line += f"\n  • guess: T={t}°C  H={h}%"
                    line += f"\n    hex: {hx}"
                show.append(line)

            self.big.markup = True
            self.big.text = "\n\n".join(show[:1])  # erstes Gerät groß
            self.raw.text = "\n\n".join(show[1:3]) # weitere klein
        except Exception as e:
            self.big.text = f"ERR: {e}"

if __name__ == "__main__":
    BridgeHeurApp().run()
