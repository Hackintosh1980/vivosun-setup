from kivy.app import App
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.core.window import Window
from jnius import autoclass
import json, os, time

Window.clearcolor = (0, 0, 0, 1)

class BridgeApp(App):
    def build(self):
        self.label = Label(
            text="[b]VIVOSUN Live-Bridge[/b]\nInitialisiere...",
            markup=True,
            font_size="28sp",
            halign="center",
            valign="middle",
            color=(0, 1, 1, 1)
        )
        Clock.schedule_once(self.start_cycle, 1)
        return self.label

    def start_cycle(self, *args):
        # Poll alle 5 Sekunden
        Clock.schedule_interval(self.scan_and_update, 5)

    def scan_and_update(self, *args):
        try:
            ctx = autoclass("org.kivy.android.PythonActivity").mActivity
            BleBridge = autoclass("org.hackintosh1980.blebridge.BleBridge")
            result = BleBridge.scan(ctx, 1500, "ble_scan.json")
            self.display_data(result)
        except Exception as e:
            self.label.text = f"[color=#ff5555]Bridge-Fehler:[/color] {e}"

    def display_data(self, result):
        path = "/data/user/0/org.hackintosh1980.vivosunreader/files/ble_scan.json"
        if not os.path.exists(path):
            self.label.text = "[color=#ffaa00]Keine JSON-Datei gefunden[/color]"
            return

        try:
            with open(path) as f:
                data = json.load(f)
            if not data:
                self.label.text = "[color=#ff5555]Keine Sensordaten[/color]"
                return

            d = data[0]
            batt_raw = d.get("battery", 0)
            battery = min(100, round(batt_raw * 100 / 255))

            self.label.text = (
                f"[b][color=#00ffaa]VIVOSUN Live-Bridge[/color][/b]\n\n"
                f"{d.get('name','?')} [b]{d.get('address','?')}[/b]\n"
                f"RSSI {d.get('rssi','?')} dBm   "
                f"[color=#999999]{time.strftime('%H:%M:%S')}[/color]\n\n"
                f"[color=#ff6666]Innen {d.get('temperature_int',0):.1f}°C[/color]   "
                f"[color=#66ccff]Aussen {d.get('temperature_ext',0):.1f}°C[/color]\n"
                f"[color=#99ff99]rLF in {d.get('humidity_int',0):.1f}%[/color]   "
                f"[color=#99ccff]rLF out {d.get('humidity_ext',0):.1f}%[/color]\n\n"
                f"[color=#ffff66]🔋 {battery}%[/color]"
            )
        except Exception as e:
            self.label.text = f"[color=#ff5555]JSON-Fehler:[/color] {e}"

if __name__ == "__main__":
    BridgeApp().run()
